<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Core\Database;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$db = new Database();
$pdo = $db->getPdo();

// Get Admin User
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute(['admin@example.com']);
$userId = $stmt->fetchColumn();

if (!$userId) {
    // Create admin if not exists
    $hash = password_hash('password', PASSWORD_ARGON2ID);
    $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES ('Admin', 'admin@example.com', ?, 'admin')")->execute([$hash]);
    $userId = $pdo->lastInsertId();
}

$vlogs = [
    [
        'title' => 'Midnight Drive in Tokyo',
        'slug' => 'midnight-drive-tokyo',
        'description' => 'A relaxing drive through the neon streets of Tokyo at night.',
        'thumbnail' => 'https://images.unsplash.com/photo-1542361345-89e58247f2d5?auto=format&fit=crop&w=600&q=80'
    ],
    [
        'title' => 'Luxury Penthouse Tour NYC',
        'slug' => 'luxury-penthouse-nyc',
        'description' => 'Touring a $50 million penthouse in Manhattan with breathtaking views.',
        'thumbnail' => 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=600&q=80'
    ],
    [
        'title' => 'Cooking Wagyu A5 Steak',
        'slug' => 'cooking-wagyu-a5',
        'description' => 'The ultimate guide to cooking the perfect A5 Wagyu steak at home.',
        'thumbnail' => 'https://images.unsplash.com/photo-1558030006-4506719866cf?auto=format&fit=crop&w=600&q=80'
    ],
    [
        'title' => 'Cinematic Travel Vlog',
        'slug' => 'cinematic-travel',
        'description' => 'Exploring the hidden gems of the Amalfi Coast.',
        'thumbnail' => 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=600&q=80'
    ],
    [
        'title' => 'Tech Review 2025',
        'slug' => 'tech-review-2025',
        'description' => 'Reviewing the latest gadgets and tech trends for the year.',
        'thumbnail' => 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=600&q=80'
    ],
    [
        'title' => 'YouTube: Ultimate Creator Guide',
        'slug' => 'youtube-creator-guide',
        'description' => 'Everything you need to know to start and grow your YouTube channel.',
        'thumbnail' => '/assets/img/youtube_logo_custom.jpg'
    ],
    [
        'title' => 'Instagram: Reels Masterclass',
        'slug' => 'instagram-reels-masterclass',
        'description' => 'Master the art of Instagram Reels and go viral.',
        'thumbnail' => '/assets/img/instagram_logo_custom.jpg'
    ],
    [
        'title' => 'Twitter: Growth Strategies',
        'slug' => 'twitter-growth-strategies',
        'description' => 'How to grow your Twitter following and engagement.',
        'thumbnail' => '/assets/img/twitter_logo_custom.jpg'
    ],
    [
        'title' => 'Gmail: Inbox Zero Hacks',
        'slug' => 'gmail-inbox-zero',
        'description' => 'Productivity hacks to reach inbox zero every day.',
        'thumbnail' => '/assets/img/gmail_logo_custom.jpg'
    ],
    [
        'title' => 'WhatsApp: Channel Updates',
        'slug' => 'whatsapp-channel-updates',
        'description' => 'Using WhatsApp Channels to connect with your audience.',
        'thumbnail' => '/assets/img/whatsapp_logo_custom.jpg'
    ],
    [
        'title' => 'Facebook: Community Building',
        'slug' => 'facebook-community-building',
        'description' => 'Building and managing thriving communities on Facebook.',
        'thumbnail' => '/assets/img/facebook_logo_custom.jpg'
    ]
];

$stmt = $pdo->prepare("INSERT INTO videos (user_id, title, slug, description, status, video_path, thumbnail_path) VALUES (:user_id, :title, :slug, :description, 'Published', '/assets/dummy.mp4', :thumbnail)");

foreach ($vlogs as $vlog) {
    // Check if exists
    $check = $pdo->prepare("SELECT id FROM videos WHERE slug = ?");
    $check->execute([$vlog['slug']]);
    if ($check->fetch()) {
        echo "Skipping {$vlog['title']} (already exists)\n";
        continue;
    }

    $stmt->execute([
        'user_id' => $userId,
        'title' => $vlog['title'],
        'slug' => $vlog['slug'],
        'description' => $vlog['description'],
        'thumbnail' => $vlog['thumbnail']
    ]);
    echo "Inserted {$vlog['title']}\n";
}

echo "Database populated successfully.\n";
