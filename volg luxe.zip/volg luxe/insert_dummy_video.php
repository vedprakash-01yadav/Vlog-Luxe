<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Core\Database;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$db = new Database();
$pdo = $db->getPdo();

// Get the first user (admin)
$stmt = $pdo->query("SELECT id FROM users LIMIT 1");
$userId = $stmt->fetchColumn();

if (!$userId) {
    die("No users found. Please register first.");
}

// Insert dummy video
$slug = 'test-video-' . uniqid();
$stmt = $pdo->prepare("INSERT INTO videos (user_id, title, slug, description, status, video_path) VALUES (:user_id, 'Test Video', :slug, 'This is a test video for social features.', 'ready', '/assets/dummy.mp4')");
$stmt->execute([
    'user_id' => $userId,
    'slug' => $slug
]);

echo "Video inserted. Slug: $slug";
