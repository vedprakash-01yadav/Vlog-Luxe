<?php

namespace App\Services;

class UploadService
{
    protected string $uploadDir;

    public function __construct()
    {
        $this->uploadDir = __DIR__ . '/../../public/uploads';
        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
    }

    public function handleUpload(array $file, string $subDir = ''): ?string
    {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $ext;
        
        $targetDir = $this->uploadDir;
        if ($subDir) {
            $targetDir .= '/' . $subDir;
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }
        }

        $targetPath = $targetDir . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            return '/uploads/' . ($subDir ? $subDir . '/' : '') . $filename;
        }

        return null;
    }
}
