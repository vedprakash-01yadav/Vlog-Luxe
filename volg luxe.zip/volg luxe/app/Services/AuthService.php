<?php

namespace App\Services;

use App\Models\User;

class AuthService
{
    protected User $userModel;

    public function __construct()
    {
        $this->userModel = new User();
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }

    public function register(string $name, string $email, string $password, string $role = 'viewer'): bool
    {
        if ($this->userModel->findByEmail($email)) {
            return false; // User exists
        }

        $hash = password_hash($password, PASSWORD_ARGON2ID);
        
        $this->userModel->create([
            'name' => $name,
            'email' => $email,
            'password_hash' => $hash,
            'role' => $role
        ]);

        return true;
    }

    public function login(string $email, string $password): bool
    {
        $user = $this->userModel->findByEmail($email);

        if (!$user || !password_verify($password, $user['password_hash'])) {
            return false;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['name'];

        return true;
    }

    public function logout()
    {
        session_destroy();
    }

    public function user()
    {
        if (!isset($_SESSION['user_id'])) {
            return null;
        }
        return $this->userModel->find($_SESSION['user_id']);
    }
}
