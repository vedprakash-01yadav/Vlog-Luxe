<?php

namespace App\Middleware;

class RateLimitMiddleware
{
    public function handle(int $limit = 60, int $timeWindow = 60)
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        $ip = $_SERVER['REMOTE_ADDR'];
        $key = 'rate_limit_' . md5($ip);
        
        $current = $_SESSION[$key] ?? ['count' => 0, 'start_time' => time()];

        // Reset if window passed
        if (time() - $current['start_time'] > $timeWindow) {
            $current = ['count' => 0, 'start_time' => time()];
        }

        $current['count']++;
        $_SESSION[$key] = $current;

        if ($current['count'] > $limit) {
            http_response_code(429);
            die("429 Too Many Requests. Please try again later.");
        }
    }
}
