<?php

namespace App\Middleware;

class AuthMiddleware
{
    public function handle()
    {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Public paths to exclude from auth check
        $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $publicPaths = ['/', '/login', '/register', '/vlogs', '/categories', '/contact', '/search'];
        
        if (in_array($uri, $publicPaths) || str_starts_with($uri, '/video/') || str_starts_with($uri, '/assets/')) {
            return;
        }

        // Check if user is logged in
        if (!isset($_SESSION['user_id'])) {
            // Redirect to login
            header('Location: /login');
            exit;
        }
    }
}
