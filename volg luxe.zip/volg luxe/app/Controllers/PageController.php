<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Video;


class PageController extends Controller
{
    public function vlogs()
    {
        // Dummy Data
        $vlogs = [
            [
                'title' => 'YouTube: Ultimate Creator Guide',
                'author' => 'YouTubeCreators',
                'views' => '5.2M',
                'duration' => '15:30',
                'thumbnail' => '/assets/img/youtube_logo_custom.jpg',
                'slug' => 'youtube-creator-guide',
                'url' => 'https://www.youtube.com/@YouTubeCreators'
            ],
            [
                'title' => 'Instagram: Reels Masterclass',
                'author' => 'InstaPro',
                'views' => '3.1M',
                'duration' => '08:45',
                'thumbnail' => '/assets/img/instagram_logo_custom.jpg',
                'slug' => 'instagram-reels-masterclass',
                'url' => 'https://www.youtube.com/@instagram'
            ],
            [
                'title' => 'Twitter: Growth Strategies',
                'author' => 'TweetMaster',
                'views' => '890K',
                'duration' => '12:10',
                'thumbnail' => '/assets/img/twitter_logo_custom.jpg',
                'slug' => 'twitter-growth-strategies',
                'url' => 'https://www.youtube.com/@X.com'
            ],
            [
                'title' => 'Gmail: Inbox Zero Hacks',
                'author' => 'ProductivityWiz',
                'views' => '2.8M',
                'duration' => '10:15',
                'thumbnail' => '/assets/img/gmail_logo_custom.jpg',
                'slug' => 'gmail-inbox-zero',
                'url' => 'https://www.youtube.com/@GoogleWorkspace'
            ],
            [
                'title' => 'WhatsApp: Channel Updates',
                'author' => 'ChatMaster',
                'views' => '6.7M',
                'duration' => '04:30',
                'thumbnail' => '/assets/img/whatsapp_logo_custom.jpg',
                'slug' => 'whatsapp-channel-updates',
                'url' => 'https://www.youtube.com/@WhatsApp'
            ],
            [
                'title' => 'Facebook: Community Building',
                'author' => 'SocialGuru',
                'views' => '4.2M',
                'duration' => '11:20',
                'thumbnail' => '/assets/img/facebook_logo_custom.jpg',
                'slug' => 'facebook-community-building',
                'url' => 'https://www.youtube.com/@Meta'
            ]
        ];

        $this->render('vlogs', ['title' => 'All Vlogs', 'vlogs' => $vlogs]);
    }

    public function categories()
    {
        $categories = [
            ['name' => 'Travel', 'count' => 120, 'image' => 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=600&q=80', 'images' => ['/assets/img/categories/travel_1.png', '/assets/img/categories/travel_2.png']],
            ['name' => 'Lifestyle', 'count' => 350, 'image' => 'https://images.unsplash.com/photo-1511988617509-a57c8a288659?auto=format&fit=crop&w=600&q=80', 'images' => ['/assets/img/categories/lifestyle_1.png', '/assets/img/categories/lifestyle_2.png']],
            ['name' => 'Tech', 'count' => 85, 'image' => 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80', 'images' => ['https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=600&q=80']],
            ['name' => 'Food', 'count' => 210, 'image' => 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&q=80', 'images' => ['https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?auto=format&fit=crop&w=600&q=80']],
            ['name' => 'Gaming', 'count' => 500, 'image' => 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80', 'images' => ['https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=600&q=80']],
            ['name' => 'Music', 'count' => 150, 'image' => 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=600&q=80', 'images' => ['https://images.unsplash.com/photo-1511379938547-c1f69419868d?auto=format&fit=crop&w=600&q=80', 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=600&q=80']]
        ];

        $this->render('categories', ['title' => 'Categories', 'categories' => $categories]);
    }

    public function home()
    {
        $trending = [
            [
                'title' => 'Cinematic Travel Vlog',
                'author' => 'TravelMaster',
                'views' => '12K',
                'thumbnail' => 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=600&q=80',
                'slug' => 'cinematic-travel',
                'url' => 'https://www.youtube.com/@PassengerParamvir'
            ],
            [
                'title' => 'Luxury Lifestyle',
                'author' => 'LuxeLife',
                'views' => '8.5K',
                'thumbnail' => '/assets/img/luxury.png',
                'slug' => 'luxury-lifestyle',
                'url' => 'https://www.youtube.com/@EnesYilmazer'
            ],
            [
                'title' => 'Tech Review 2025',
                'author' => 'TechGuru',
                'views' => '25K',
                'thumbnail' => 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=600&q=80',
                'slug' => 'tech-review-2025',
                'url' => 'https://www.youtube.com/@mkbhd'
            ]
        ];

        $latest = [
            [
                'title' => 'Morning Routine',
                'author' => 'DailyVlog',
                'views' => '5K',
                'thumbnail' => 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80',
                'slug' => 'morning-routine',
                'url' => 'https://www.youtube.com/user/yogawithadriene'
            ],
            [
                'title' => 'Street Food Tour',
                'author' => 'FoodieKing',
                'views' => '150K',
                'thumbnail' => 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=600&q=80',
                'slug' => 'street-food-tour',
                'url' => 'https://www.youtube.com/@BestEverFoodReviewShow'
            ],
            [
                'title' => 'Gaming Setup Tour',
                'author' => 'GamerPro',
                'views' => '45K',
                'thumbnail' => '/assets/img/gaming_setup.png',
                'slug' => 'gaming-setup',
                'url' => 'https://www.youtube.com/@TotalGaming093'
            ]
        ];

        $this->render('home', [
            'title' => 'Home',
            'trending' => $trending,
            'latest' => $latest
        ]);
    }

    public function contact()
    {
        $this->render('contact', ['title' => 'Contact Us']);
    }

    public function search()
    {
        $query = $_GET['q'] ?? '';
        $results = [];

        if (!empty($query)) {
            $videoModel = new Video();
            $results = $videoModel->search($query);
        }

        $this->render('search', [
            'title' => 'Search Results',
            'query' => $query,
            'results' => $results
        ]);
    }
}

