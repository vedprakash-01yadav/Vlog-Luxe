<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\User;

class UserController extends Controller
{
    protected User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = new User();
    }

    public function editProfile()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $user = $this->userModel->find($_SESSION['user_id']);
        $this->render('user/profile', ['title' => 'Edit Profile', 'user' => $user]);
    }

    public function updateProfile()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $name = $_POST['name'] ?? '';
        $bio = $_POST['bio'] ?? '';
        $avatarUrl = $_POST['avatar_url'] ?? '';

        // In a real app, we would handle file uploads for avatar here.
        // For now, we'll just update the text fields.

        $this->userModel->update($_SESSION['user_id'], [
            'name' => $name,
            'bio' => $bio,
            'avatar_url' => $avatarUrl
        ]);

        $_SESSION['user_name'] = $name; // Update session name

        header('Location: /profile');
        exit;
    }
}
