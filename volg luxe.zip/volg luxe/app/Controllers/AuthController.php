<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Services\AuthService;

class AuthController extends Controller
{
    protected AuthService $auth;

    public function __construct()
    {
        parent::__construct();
        $this->auth = new AuthService();
    }

    public function showLogin()
    {
        $this->render('auth/login', ['title' => 'Login']);
    }

    public function showRegister()
    {
        $this->render('auth/register', ['title' => 'Register']);
    }

    public function login()
    {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if ($this->auth->login($email, $password)) {
            header('Location: /dashboard');
            exit;
        }

        $this->render('auth/login', ['error' => 'Invalid credentials', 'title' => 'Login']);
    }

    public function register()
    {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        if ($this->auth->register($name, $email, $password)) {
            header('Location: /login');
            exit;
        }

        $this->render('auth/register', ['error' => 'Registration failed (Email might be taken)', 'title' => 'Register']);
    }

    public function logout()
    {
        $this->auth->logout();
        header('Location: /');
        exit;
    }
}
