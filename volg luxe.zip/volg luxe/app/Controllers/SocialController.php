<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Comment;
use App\Models\Like;

class SocialController extends Controller
{
    public function postComment()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $videoId = $_POST['video_id'] ?? null;
        $body = $_POST['body'] ?? null;

        if ($videoId && $body) {
            $commentModel = new Comment();
            $commentModel->create([
                'user_id' => $_SESSION['user_id'],
                'video_id' => $videoId,
                'body' => htmlspecialchars($body)
            ]);
        }

        // Redirect back to video page
        // Ideally we'd have the slug, but for now let's just go back
        if (isset($_SERVER['HTTP_REFERER'])) {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        } else {
            header('Location: /vlogs');
        }
        exit;
    }

    public function toggleLike()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $videoId = $input['video_id'] ?? null;

        if ($videoId) {
            $likeModel = new Like();
            $liked = $likeModel->toggle($_SESSION['user_id'], $videoId);
            $count = $likeModel->getCount($videoId);

            header('Content-Type: application/json');
            echo json_encode(['liked' => $liked, 'count' => $count]);
            exit;
        }
    }
}
