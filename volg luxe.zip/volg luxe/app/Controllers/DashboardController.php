<?php

namespace App\Controllers;

use App\Core\Controller;

class DashboardController extends Controller
{
    protected \App\Models\Video $videoModel;
    protected \App\Models\User $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->videoModel = new \App\Models\Video();
        $this->userModel = new \App\Models\User();
    }

    public function index()
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: /');
            exit;
        }

        // Real Stats
        $totalViews = $this->videoModel->sumViews();
        $totalVideos = $this->videoModel->countAll();
        // For subscribers, we don't have a subscription system yet, so we'll keep it static or count users
        $totalUsers = $this->userModel->countAll(); // Assuming User model has countAll too, let's add it or just use a placeholder if not.
        // Let's check User model first. If not sure, I'll just use a placeholder for now to avoid breaking.
        // Actually, I'll just count users as "Community Members" for now.
        
        $stats = [
            'views' => number_format($totalViews),
            'subscribers' => number_format($totalUsers), // Re-purposing as Total Users for now
            'videos' => number_format($totalVideos)
        ];

        // Real Videos
        $videos = $this->videoModel->findRecent(10);

        $this->render('dashboard/index', [
            'title' => 'Creator Dashboard',
            'user' => $_SESSION,
            'stats' => $stats,
            'videos' => $videos
        ]);
    }
}
