<?php

namespace App\Controllers;

use App\Core\Controller;
use App\Models\Video;
use App\Services\UploadService;
use App\Services\MediaService;

use App\Models\Comment;
use App\Models\Like;

class ContentController extends Controller
{
    protected Video $videoModel;
    protected UploadService $uploadService;
    protected MediaService $mediaService;
    protected Comment $commentModel;
    protected Like $likeModel;

    public function __construct()
    {
        parent::__construct();
        $this->videoModel = new Video();
        $this->uploadService = new UploadService();
        $this->mediaService = new MediaService();
        $this->commentModel = new Comment();
        $this->likeModel = new Like();
    }

    public function showUpload()
    {
        // Auth check should be middleware, but for safety:
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }
        $this->render('content/upload', ['title' => 'Upload Content']);
    }

    public function uploadVideo()
    {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        $title = $_POST['title'] ?? 'Untitled';
        $description = $_POST['description'] ?? '';
        $file = $_FILES['video_file'] ?? null;

        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            $this->render('content/upload', ['error' => 'File upload failed', 'title' => 'Upload Content']);
            return;
        }

        $path = $this->uploadService->handleUpload($file, 'videos');
        
        if (!$path) {
            $this->render('content/upload', ['error' => 'Could not save file', 'title' => 'Upload Content']);
            return;
        }

        // Create slug
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        $slug .= '-' . uniqid();

        $videoId = $this->videoModel->create([
            'user_id' => $_SESSION['user_id'],
            'title' => $title,
            'slug' => $slug,
            'description' => $description,
            'status' => 'processing',
            'video_path' => $path
        ]);

        // Trigger async processing (mock)
        // $this->mediaService->processVideo($path, ...);

        header('Location: /video/' . $slug);
        exit;
    }

    public function showVideo(string $slug)
    {

        $video = $this->videoModel->findBySlug($slug);
        
        if (!$video) {
            http_response_code(404);
            echo "Video not found";
            return;
        }

        $comments = $this->commentModel->getByVideoId($video['id']);
        $likeCount = $this->likeModel->getCount($video['id']);
        $hasLiked = false;
        
        if (isset($_SESSION['user_id'])) {
            $hasLiked = $this->likeModel->hasLiked($_SESSION['user_id'], $video['id']);
        }

        $this->render('content/video', [
            'video' => $video, 
            'title' => $video['title'],
            'comments' => $comments,
            'like_count' => $likeCount,
            'has_liked' => $hasLiked,
            'test_var' => 'Hello World'
        ]);
    }

    public function deleteVideo(string $slug)
    {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: /');
            exit;
        }

        if ($this->videoModel->delete($slug)) {
            header('Location: /dashboard');
            exit;
        }

        // Handle error if needed
        header('Location: /dashboard?error=delete_failed');
        exit;
    }
}
