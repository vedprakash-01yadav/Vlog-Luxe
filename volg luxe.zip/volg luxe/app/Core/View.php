<?php

namespace App\Core;

use Twig\Loader\FilesystemLoader;
use Twig\Environment;

class View
{
    protected Environment $twig;

    public function __construct()
    {
        $loader = new FilesystemLoader(__DIR__ . '/../../resources/views');
        
        $cache = $_ENV['APP_ENV'] === 'production' ? __DIR__ . '/../../storage/cache' : false;

        $this->twig = new Environment($loader, [
            'cache' => $cache,
            'debug' => $_ENV['APP_DEBUG'] === 'true',
        ]);
        

    }

    public function render(string $template, array $data = [])
    {
        // Ensure session is always available and fresh
        $data = array_merge(['session' => $_SESSION ?? []], $data);
        echo $this->twig->render($template . '.twig', $data);
    }

}
