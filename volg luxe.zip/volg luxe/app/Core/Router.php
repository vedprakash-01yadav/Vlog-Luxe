<?php

namespace App\Core;

use Bramus\Router\Router as BramusRouter;

class Router
{
    protected BramusRouter $router;

    public function __construct()
    {
        $this->router = new BramusRouter();
    }

    public function dispatch()
    {
        // Load routes
        require_once __DIR__ . '/../../routes/web.php';

        $this->router->run();
    }

    public function get(string $pattern, $callback)
    {
        $this->router->get($pattern, $callback);
    }

    public function post(string $pattern, $callback)
    {
        $this->router->post($pattern, $callback);
    }
    
    public function mount(string $pattern, $callback)
    {
        $this->router->mount($pattern, $callback);
    }

    public function before(string $methods, string $pattern, $callback)
    {
        $this->router->before($methods, $pattern, $callback);
    }
}
