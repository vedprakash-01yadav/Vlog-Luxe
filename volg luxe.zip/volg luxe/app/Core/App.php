<?php

namespace App\Core;

class App
{
    protected Router $router;
    protected Database $db;
    protected View $view;

    public function __construct()
    {
        $this->db = new Database();
        $this->view = new View();
        $this->router = new Router();
    }

    public function run()
    {
        $this->router->dispatch();
    }

    public static function getDb(): Database
    {
        // Singleton-like access for simplicity in this MVC
        global $app;
        return $app->db;
    }
}
