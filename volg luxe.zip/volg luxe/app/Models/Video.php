<?php

namespace App\Models;

use App\Core\Model;

class Video extends Model
{
    protected string $table = 'videos';

    public function create(array $data): int
    {
        $sql = "INSERT INTO videos (user_id, title, slug, description, status, video_path, created_at) 
                VALUES (:user_id, :title, :slug, :description, :status, :video_path, :created_at)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'user_id' => $data['user_id'],
            'title' => $data['title'],
            'slug' => $data['slug'],
            'description' => $data['description'] ?? '',
            'status' => $data['status'] ?? 'processing',
            'video_path' => $data['video_path'],
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function findBySlug(string $slug)
    {
        $stmt = $this->db->prepare("SELECT * FROM videos WHERE slug = :slug");
        $stmt->execute(['slug' => $slug]);
        return $stmt->fetch();
    }
    public function search(string $query)
    {
        $stmt = $this->db->prepare("SELECT * FROM videos WHERE title LIKE :query OR description LIKE :query ORDER BY created_at DESC");
        $stmt->execute(['query' => "%$query%"]);
        return $stmt->fetchAll();
    }
    public function countAll(): int
    {
        $stmt = $this->db->query("SELECT COUNT(*) FROM videos");
        return (int)$stmt->fetchColumn();
    }

    public function sumViews(): int
    {
        // Assuming there is a 'views' column. If not, we might need to add it or return 0.
        // Based on previous context, 'views' might not be in the create method but should be in the table.
        // Let's check schema if possible, but for now assuming it exists or defaulting to 0.
        // Actually, looking at the create method, 'views' wasn't inserted. 
        // Let's assume it defaults to 0 in DB.
        $stmt = $this->db->query("SELECT SUM(views) FROM videos");
        return (int)$stmt->fetchColumn();
    }

    public function findRecent(int $limit = 5): array
    {
        $stmt = $this->db->prepare("SELECT * FROM videos ORDER BY created_at DESC LIMIT :limit");
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function delete(string $slug): bool
    {
        $stmt = $this->db->prepare("DELETE FROM videos WHERE slug = :slug");
        return $stmt->execute(['slug' => $slug]);
    }
}

