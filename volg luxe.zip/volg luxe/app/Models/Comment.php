<?php

namespace App\Models;

use App\Core\Model;

class Comment extends Model
{
    protected string $table = 'comments';

    public function create(array $data)
    {
        $stmt = $this->db->prepare("INSERT INTO {$this->table} (user_id, video_id, body) VALUES (:user_id, :video_id, :body)");
        $stmt->execute([
            'user_id' => $data['user_id'],
            'video_id' => $data['video_id'],
            'body' => $data['body']
        ]);
        return $this->db->lastInsertId();
    }

    public function getByVideoId($videoId)
    {
        $stmt = $this->db->prepare("
            SELECT c.*, u.name as user_name, u.avatar_url 
            FROM {$this->table} c 
            JOIN users u ON c.user_id = u.id 
            WHERE c.video_id = :video_id 
            ORDER BY c.created_at DESC
        ");
        $stmt->execute(['video_id' => $videoId]);
        return $stmt->fetchAll();
    }
}
