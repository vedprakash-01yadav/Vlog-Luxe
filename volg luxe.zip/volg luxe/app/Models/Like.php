<?php

namespace App\Models;

use App\Core\Model;

class Like extends Model
{
    protected string $table = 'likes';

    public function toggle($userId, $videoId)
    {
        // Check if exists
        $stmt = $this->db->prepare("SELECT id FROM {$this->table} WHERE user_id = :user_id AND video_id = :video_id");
        $stmt->execute(['user_id' => $userId, 'video_id' => $videoId]);
        $exists = $stmt->fetch();

        if ($exists) {
            // Unlike
            $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE id = :id");
            $stmt->execute(['id' => $exists['id']]);
            return false; // Not liked anymore
        } else {
            // Like
            $stmt = $this->db->prepare("INSERT INTO {$this->table} (user_id, video_id) VALUES (:user_id, :video_id)");
            $stmt->execute(['user_id' => $userId, 'video_id' => $videoId]);
            return true; // Liked
        }
    }

    public function getCount($videoId)
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM {$this->table} WHERE video_id = :video_id");
        $stmt->execute(['video_id' => $videoId]);
        return $stmt->fetchColumn();
    }

    public function hasLiked($userId, $videoId)
    {
        $stmt = $this->db->prepare("SELECT id FROM {$this->table} WHERE user_id = :user_id AND video_id = :video_id");
        $stmt->execute(['user_id' => $userId, 'video_id' => $videoId]);
        return (bool) $stmt->fetch();
    }
}
