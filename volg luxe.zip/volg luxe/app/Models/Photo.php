<?php

namespace App\Models;

use App\Core\Model;

class Photo extends Model
{
    protected string $table = 'photos';

    public function create(array $data): int
    {
        $sql = "INSERT INTO photos (user_id, title, slug, description, file_path, width, height, created_at) 
                VALUES (:user_id, :title, :slug, :description, :file_path, :width, :height, :created_at)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            'user_id' => $data['user_id'],
            'title' => $data['title'],
            'slug' => $data['slug'],
            'description' => $data['description'] ?? '',
            'file_path' => $data['file_path'],
            'width' => $data['width'] ?? 0,
            'height' => $data['height'] ?? 0,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        return (int)$this->db->lastInsertId();
    }
}
