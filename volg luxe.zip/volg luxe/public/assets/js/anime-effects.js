document.addEventListener('DOMContentLoaded', () => {
    // Sparkle Effect
    document.addEventListener('click', (e) => {
        createSparkle(e.clientX, e.clientY);
    });

    function createSparkle(x, y) {
        const sparkle = document.createElement('div');
        sparkle.classList.add('sparkle');
        sparkle.style.left = `${x}px`;
        sparkle.style.top = `${y}px`;
        
        // Randomize sparkle properties
        const size = Math.random() * 20 + 10;
        sparkle.style.width = `${size}px`;
        sparkle.style.height = `${size}px`;
        sparkle.style.background = `radial-gradient(circle, #fff, ${Math.random() > 0.5 ? '#ff007f' : '#00d4ff'})`;
        sparkle.style.position = 'fixed';
        sparkle.style.borderRadius = '50%';
        sparkle.style.pointerEvents = 'none';
        sparkle.style.zIndex = '9999';
        sparkle.style.transform = 'translate(-50%, -50%) scale(0)';
        sparkle.style.transition = 'transform 0.5s ease-out, opacity 0.5s ease-out';
        
        document.body.appendChild(sparkle);

        // Animate
        requestAnimationFrame(() => {
            sparkle.style.transform = 'translate(-50%, -50%) scale(1)';
            sparkle.style.opacity = '0';
        });

        // Cleanup
        setTimeout(() => {
            sparkle.remove();
        }, 500);
    }

    // 3D Tilt Effect for Cards
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = ((y - centerY) / centerY) * -5; // Max 5deg rotation
            const rotateY = ((x - centerX) / centerX) * 5;

            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale(1.02)`;
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) scale(1)';
        });
    });
});
