<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Core\Database;
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
$db = new Database();
echo $db->getPdo()->query('SELECT slug FROM videos ORDER BY id DESC LIMIT 1')->fetchColumn();
