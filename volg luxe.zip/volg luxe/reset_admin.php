<?php
require_once __DIR__ . '/vendor/autoload.php';
use App\Core\Database;
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
$db = new Database();
$pdo = $db->getPdo();
$hash = password_hash('password', PASSWORD_ARGON2ID);
$pdo->prepare('UPDATE users SET password_hash = ? WHERE email = ?')->execute([$hash, 'admin@example.com']);
echo "Password reset successfully.\n";
