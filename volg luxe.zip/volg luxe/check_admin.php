<?php

require_once __DIR__ . '/vendor/autoload.php';

use App\Core\Database;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$db = new Database();
$pdo = $db->getPdo();

$email = 'admin@example.com';
$password = 'password';

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
$stmt->execute(['email' => $email]);
$user = $stmt->fetch();

if ($user) {
    echo "Admin user exists.\n";
    echo "ID: " . $user['id'] . "\n";
    echo "Email: " . $user['email'] . "\n";
    echo "Password: (hidden, but likely 'password')\n";
} else {
    $hash = password_hash($password, PASSWORD_ARGON2ID);
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, role) VALUES ('Admin', :email, :hash, 'admin')");
    $stmt->execute([
        'email' => $email,
        'hash' => $hash
    ]);
    echo "Admin user created.\n";
    echo "Email: $email\n";
    echo "Password: $password\n";
}
