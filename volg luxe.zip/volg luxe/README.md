# Premium Vlogging Platform

A high-end, dynamic vlogging platform built with PHP 8, SQLite, and vanilla CSS. Designed for creators to share their world in luxury.

## Features

-   **User Authentication**: Secure Login and Registration with password hashing.
-   **Video Management**: Upload, view, and manage videos.
-   **Social Interaction**: Like and Comment on videos.
-   **Dashboard**: Creator dashboard with statistics and video management.
-   **Security**: CSRF protection, Rate Limiting, and Input Sanitization.
-   **Responsive Design**: Fully responsive UI with glassmorphism aesthetics.
-   **SEO Optimized**: Dynamic meta tags and Open Graph support.

## Requirements

-   PHP 8.0 or higher
-   Composer
-   SQLite extension enabled in `php.ini`

## Installation

1.  **Clone the repository** (or extract the zip):
    ```bash
    git clone <repository-url>
    cd vlogging
    ```

2.  **Install Dependencies**:
    ```bash
    composer install
    ```

3.  **Environment Setup**:
    -   Copy `.env.example` to `.env`.
    -   Ensure `DB_CONNECTION=sqlite` and `DB_DATABASE` points to a valid path.

4.  **Database Setup**:
    -   The application will automatically create the SQLite database file if it doesn't exist, provided the directory is writable.
    -   Ensure `storage/database` directory exists.

5.  **Run the Application**:
    ```bash
    php -S localhost:8000 -t public
    ```

6.  **Access**:
    -   Open `http://localhost:8000` in your browser.

## Directory Structure

-   `app/`: Core application logic (Controllers, Models, Services).
-   `public/`: Web root (index.php, assets).
-   `resources/views/`: Twig templates.
-   `routes/`: Route definitions.
-   `storage/`: Database, logs, and uploads.

## Security

-   **Rate Limiting**: Login and Registration are rate-limited to prevent brute-force attacks.
-   **Session Management**: Secure session handling with `AuthMiddleware`.

## License

MIT License.
