<?php

/** @var \App\Core\Router $this */

$pages = new \App\Controllers\PageController();
$rateLimit = new \App\Middleware\RateLimitMiddleware();
$authMiddleware = new \App\Middleware\AuthMiddleware();

// Apply auth middleware globally
$this->before('GET|POST', '/.*', fn() => $authMiddleware->handle());


$this->get('/', fn() => $pages->home());

$auth = new \App\Controllers\AuthController();

$this->get('/login', fn() => $auth->showLogin());
$this->post('/login', function() use ($auth, $rateLimit) {
    $rateLimit->handle(5, 60); // 5 attempts per minute
    $auth->login();
});


$this->get('/register', fn() => $auth->showRegister());
$this->post('/register', function() use ($auth, $rateLimit) {
    $rateLimit->handle(3, 60); // 3 attempts per minute
    $auth->register();
});


$this->get('/logout', fn() => $auth->logout());

$dashboard = new \App\Controllers\DashboardController();
$this->get('/dashboard', fn() => $dashboard->index());

$userController = new \App\Controllers\UserController();
$this->get('/profile', fn() => $userController->editProfile());
$this->post('/profile', fn() => $userController->updateProfile());

$content = new \App\Controllers\ContentController();

$this->get('/upload', fn() => $content->showUpload());
$this->post('/upload/video', fn() => $content->uploadVideo());
$this->post('/video/delete/([\w-]+)', fn($slug) => $content->deleteVideo($slug));
$this->get('/video/([\w-]+)', fn($slug) => $content->showVideo($slug));

$this->get('/vlogs', fn() => $pages->vlogs());
$this->get('/categories', fn() => $pages->categories());
$this->get('/contact', fn() => $pages->contact());
$this->get('/search', fn() => $pages->search());

// Social Routes
$social = new \App\Controllers\SocialController();
$this->post('/comments', function() use ($social, $rateLimit) {
    $rateLimit->handle(10, 60); // 10 comments per minute
    $social->postComment();
});

$this->post('/likes/toggle', fn() => $social->toggleLike());
